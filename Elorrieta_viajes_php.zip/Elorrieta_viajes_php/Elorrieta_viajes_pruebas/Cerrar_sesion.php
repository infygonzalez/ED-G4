<?php
session_start();
session_destroy(); // Cierra sesión
header("Location: index.php"); // Redirige al login
exit();
?>
<script>
     
     window.history.pushState(null, "", window.location.href);
    window.onpopstate = function() {
        window.history.pushState(null, "", window.location.href);
       
    };
</script>