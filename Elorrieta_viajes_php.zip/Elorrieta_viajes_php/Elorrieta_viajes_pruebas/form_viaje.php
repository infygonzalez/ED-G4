<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="estilos_formulario.css">
    <title>Registrar viaje</title>
    <script>
        function calcularDias() {
            let fechaInicio = document.getElementById("fecha-inicio");
            let fechaFin = document.getElementById("fecha-fin");
            let hoy = new Date().toISOString().split("T")[0];

            fechaInicio.setAttribute("min", hoy);
            
            if (fechaInicio.value) {
                fechaFin.setAttribute("min", fechaInicio.value);
            }

            if (fechaInicio.value && fechaFin.value) {
                let inicio = new Date(fechaInicio.value);
                let fin = new Date(fechaFin.value);
                let diferencia = Math.ceil((fin - inicio) / (1000 * 60 * 60 * 24));
                document.getElementById("dias").value = diferencia > 0 ? diferencia : 0;
            }
        }

        document.addEventListener("DOMContentLoaded", () => {
            document.getElementById("fecha-inicio").setAttribute("min", new Date().toISOString().split("T")[0]);
        });
    </script>
</head>
<body>
    <header>
        <img class="cabecera" src="Imgs/cabecera.jpg" alt="Fondo del encabezado">
        <div class="titulo">Erreka-Mari Viajes</div>
    </header>
    <div class="CerrarSesion"> 
        <a href="Cerrar_sesion.php" class="cta">
            <svg width="10px" height="10px" viewBox="0 0 13 10">
                <path d="M12,5 L2,5"></path>
                <polyline points="5 1 1 5 5 9"></polyline>
            </svg>
            <span>Cerrar Sesión</span>
        </a><br>
    </div>
    <div class="subtitulo"> 
        <h2>Bienvenido al Registro de Viajes</h2>
    </div>
    <div class="container">
        <h2>Nuevo Viaje</h2>

        <?php
        session_start();
        if (!isset($_SESSION['AgenciaID'])) {
            header("Location: index.php");
            exit();
        }
        
        error_reporting(E_ALL);
        ini_set('display_errors', 1);
        
        $conn = new mysqli("localhost", "root", "", "reto2");
        if ($conn->connect_error) {
            die("Conexión fallida: " . $conn->connect_error);
        }
        
        if ($_SERVER["REQUEST_METHOD"] == "POST") {
            $agenciaID = $_SESSION['AgenciaID'];
            $nombre = $conn->real_escape_string($_POST["nombre"]);
            $tipo_viaje = $conn->real_escape_string($_POST["tipo-viaje"]);
            $fecha_inicio = $conn->real_escape_string($_POST["fecha-inicio"]);
            $fecha_fin = $conn->real_escape_string($_POST["fecha-fin"]);
            $destino = $conn->real_escape_string($_POST["destino"]);
            $descripcion = $conn->real_escape_string($_POST["descripcion"]);
            $servicios_excluidos = isset($_POST["ServiciosNoIncluidos"]) ? $conn->real_escape_string($_POST["ServiciosNoIncluidos"]) : '';
        
            $sql_check_destino = "SELECT PaisID FROM paises WHERE PaisID = '$destino'";
            $result_check_destino = $conn->query($sql_check_destino);
            if ($result_check_destino->num_rows == 0) {
                echo "<script>alert('El destino seleccionado no es válido'); window.location.href='form_viaje.php';</script>";
            } else {
                $sql = "INSERT INTO Viajes (AgenciaID, Nombre, TipoViaje, FechaInicio, FechaFin, PaisID, Descripcion, ServiciosNoIncluidos)
                        VALUES ('$agenciaID', '$nombre', '$tipo_viaje', '$fecha_inicio', '$fecha_fin', '$destino', '$descripcion', '$servicios_excluidos')";
        
                if ($conn->query($sql) === TRUE) {
                    echo "<script>alert('Viaje registrado correctamente'); window.location.href='form_viaje.php';</script>";
                } else {
                    echo "Error: " . $conn->error;
                }
            }
        }
        $conn->close();
        ?>

        <form action="" method="POST" id="form-viaje" class="servicio">
            <p><b>Vuelo</b></p>
            <hr>
            <label for="nombre">Nombre:</label>
            <input type="text" id="nombre" name="nombre" placeholder="Tu nombre" required>

            <label for="tipo-viaje">Tipo de viaje:</label>
            <select id="tipo-viaje" name="tipo-viaje" required>
                <option value="" disabled selected>--Selecciona una opción--</option>
                <option value="novios">Novios</option>
                <option value="senior">Senior</option>
                <option value="grupos">Grupos</option>
                <option value="grandes-viajes">Grandes viajes (destinos exóticos)</option>
                <option value="combinado">Combinado (vuelo + hotel)</option>
                <option value="escapadas">Escapadas</option>
                <option value="familias-ninos">Familias con niños menores</option>
            </select>

            <label for="fecha-inicio">Fecha de inicio:</label>
            <input type="date" id="fecha-inicio" name="fecha-inicio" required onchange="calcularDias()">

            <label for="fecha-fin">Fecha de fin:</label>
            <input type="date" id="fecha-fin" name="fecha-fin" required onchange="calcularDias()">

            <label for="dias">Días:</label>
            <input type="number" id="dias" name="dias" value="" readonly>

            <label>Destino:</label>
            <select id="pais" name="destino" required>
                <option value="" disabled selected>--Selecciona una opción--</option>
                <?php
                $conn = new mysqli("localhost", "root", "", "reto2");
                if (!$conn->connect_error) {
                    $sql = "SELECT PaisID, Nombre FROM paises ORDER BY Nombre ASC";
                    $result = $conn->query($sql);
                    while ($row = $result->fetch_assoc()) {
                        echo '<option value="' . $row['PaisID'] . '">' . $row['Nombre'] . '</option>';
                    }
                    $conn->close();
                }
                ?>
            </select>

            <label>Descripción:</label>
            <textarea id="descripcion" name="descripcion" placeholder="Añade una descripción"></textarea>

            <label>Servicios excluidos:</label>
            <textarea id="ServiciosNoIncluidos" name="ServiciosNoIncluidos" placeholder="Añade los servicios excluidos"></textarea>

            <button type="submit">Guardar</button>
        </form>
    </div>
</body>
</html>
