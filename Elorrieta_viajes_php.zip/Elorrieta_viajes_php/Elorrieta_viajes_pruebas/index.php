<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="estilos_inicio.css">
    <link rel="shortcut icon" href="Imgs/logo.ico">
    <title>Erreka-Mari Viajes</title>
</head>
<body>
    <header>
        <img class="cabecera" src="Imgs/cabecera.jpg" alt="Fondo del encabezado">
        <div class="titulo">Erreka-Mari Viajes</div>
    </header>

    <div class="IniSesion">
        <h2>Inicio de Sesión</h2>
        <form id="loginForm" method="post" action="login.php">
            <label for="usuario">Usuario:</label><br>
            <input type="text" id="usuario" name="usuario" required><br>

            <label for="contraseña">Contraseña:</label><br>
            <input type="password" id="contraseña" name="contraseña" required><br><br>

            <button type="submit"><b>Iniciar Sesión</b></button>
        </form>
        <p id="mensaje" style="color:red;"></p>
    </div>

    <footer>
        <a href="https://creativecommons.org/">
            <img src="Imgs/creative_comons.png" title="Esta página está bajo la licencia de Creative Commons. Pulsa para más información" alt="logo" width="180" class="imagen">
        </a>
        <p class="copyright">&copy; <b>Erreka-Mari Viajes</b></p>
    </footer>

    <script>
        // Bloqueo de la navegación hacia atrás (opcional)

        // Envío del formulario mediante fetch
        document.getElementById("loginForm").addEventListener("submit", function(event) {
            event.preventDefault(); // Evita el envío tradicional del formulario
            
            let formData = new FormData(this);

            fetch("login.php", {
                method: "POST",
                body: formData
            })
            .then(response => response.text())
            .then(data => {
                if (data.trim() === "success") {
                    window.location.href = "ventana2.php"; // Redirige si el login es correcto
                } else {
                    document.getElementById("mensaje").textContent = "❌ Usuario o contraseña incorrectos";
                }
            })
            .catch(error => console.error("Error:", error));
        });
    </script>
</body>
</html>
