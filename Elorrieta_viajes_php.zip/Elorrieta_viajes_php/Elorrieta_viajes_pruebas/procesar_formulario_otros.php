<?php
                // Incluir la conexión a la base de datos
                $servername = "localhost"; 
                $username = "root"; 
                $password = "";
                $dbname = "reto2"; 

                $conn = new mysqli($servername, $username, $password, $dbname);

                // Verificar conexión
                if ($conn->connect_error) {
                    die("Error de conexión: " . $conn->connect_error);
                }

                // Verificar si el formulario fue enviado
                if ($_SERVER["REQUEST_METHOD"] == "POST") {
                    // Capturar los valores enviados del formulario de vuelo
                    
                    $viajeID_otros = $conn->real_escape_string($_POST["viajeID_otros"]);
                    $nombre_servicio = $conn->real_escape_string($_POST["nombre_servicio"]);
                    $descripcion = $conn->real_escape_string($_POST["descripcion"]);
                    $fecha = $conn->real_escape_string($_POST["fecha"]);  
                    $precio_otros = $conn->real_escape_string($_POST["precio_otros"]);
                

                        $sql = "INSERT INTO Actividades (ViajeID, NombreEvento, Descripcion, Fecha, Precio)
                                VALUES ('$viajeID_otros', '$nombre_servicio', '$descripcion', '$fecha', '$precio_otros')";
                
                        if ($conn->query($sql) === TRUE) {
                            echo "<script>alert('Viaje registrado correctamente'); window.location.href='form_planificacion.php';</script>";
                        } else {
                            echo "Error: " . $conn->error;
                        }
                    }
                
                $conn->close();
                ?>