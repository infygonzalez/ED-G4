<?php
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "reto2";

// Crear conexión a la base de datos
$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Error en la conexión: " . $conn->connect_error);
}

// Verificar que se envíe el formulario por POST
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (!isset($_POST['usuario']) || !isset($_POST['contraseña'])) {
        echo "Faltan datos en el formulario.";
        exit;
    }
    
    $usuario = trim($_POST['usuario']);
    $contraseña = trim($_POST['contraseña']);

    if (empty($usuario) || empty($contraseña)) {
        echo "El usuario y la contraseña no pueden estar vacíos.";
        exit;
    }

    // Buscar la agencia por usuario (Nombre en este caso) y contraseña
    $stmt = $conn->prepare("SELECT AgenciaID, Nombre FROM agencias WHERE Nombre = ? AND Contraseña = ?");
    if (!$stmt) {
        echo "Error en la preparación de la consulta: " . $conn->error;
        exit;
    }
    
    $stmt->bind_param("ss", $usuario, $contraseña);
    $stmt->execute();
    $result = $stmt->get_result();

    //captura agenciaID para su uso en el formulario de viaje
    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $_SESSION['username'] = $row['Nombre'];
        $_SESSION['AgenciaID'] = $row['AgenciaID'];
        echo "success";
    } else {
        echo "Usuario o contraseña incorrectos.";
    }

    $stmt->close();
}

$conn->close();

?>
