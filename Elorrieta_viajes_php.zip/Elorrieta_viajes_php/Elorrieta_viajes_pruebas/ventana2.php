<?php
session_start();
if (!isset($_SESSION['username'])) {
    header("Location: index.php"); // Redirigir si no hay sesión iniciada
    exit();
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="estilos_ventana2.css">
    <link rel="stylesheet" href="estilos_inicio.js">
    <title>Erreka-Mari Viajes</title>
</head>
<body>
    <header>
        <img class="cabecera" src="Imgs/cabecera.jpg" alt="Fondo del encabezado">
        <div class="titulo">Erreka-Mari Viajes</div>
    </header>
    <div id="cerrar_sesion" class="CerrarSesion">   
        <a href="Cerrar_sesion.php" class="cta">
            <svg width="10px" height="10px" viewBox="0 0 13 10">
                <path d="M12,5 L2,5"></path>
                <polyline points="5 1 1 5 5 9"></polyline>
            </svg>
            <span>Cerrar Sesión</span>
        </a><br>
    </div>
    <div class="usu">
    <p></b>Bienvenido, <?php echo htmlspecialchars($_SESSION['username']); ?></b></p>
    </div>
    <div class="IniSesion">
       <p class="Viajes"> Un viaje mas autentico diseñado por y para ti con experiencias inolvidables </p>
        <div class="RegistrarViajes">   
            <a href="form_viaje.php" class="cta">
                <span>Registrar viaje</span>
                <svg width="15px" height="15px" viewBox="0 0 13 10">
                    <path d="M1,5 L11,5"></path>
                    <polyline points="8 1 12 5 8 9"></polyline>
                </svg>
            </a><br>
            </div>
            <div class="RegistrarViajes">
            <a href="form_planificacion.php" class="cta">
                <span>Registrar servicio</span>
                <svg width="13px" height="10px" viewBox="0 0 13 10">
                    <path d="M1,5 L11,5"></path>
                    <polyline points="8 1 12 5 8 9"></polyline>
                </svg>
            </a>
            </div>
    </div>

    <footer>
        <a href="https://creativecommons.org/"> 
            <img src="Imgs/creative_comons.png" title="Esta página esta bajo la licencia de Creative Commons. Pulsa para más información" alt="logo" width="180" class="imagen"> 
        </a>
        <p class="copyright"> &copy; <b>Erreka-Mari Viajes</b></p>
    </footer> 
</body>
<script>
    document.getElementById("cerrar_sesion ").addEventListener("click", function(event) {
        event.preventDefault();
        window.location.replace("index.php");
    });
</script>
</html>
