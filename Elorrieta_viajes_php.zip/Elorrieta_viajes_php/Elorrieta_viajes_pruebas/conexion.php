<?php
$servername = "localhost"; // Servidor MySQL
$username = "root"; // Usuario 'root'
$password = ""; // Contraseña de root (si no tienes contraseña, déjalo vacío)
$dbname = "reto2"; // Nombre de la base de datos

// Crear conexión
$conn = new mysqli($servername, $username, $password, $dbname);

// Verificar conexión
if ($conn->connect_error) {
    die("Error en la conexión: " . $conn->connect_error);
}
?>
