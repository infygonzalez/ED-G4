<?php
                // Incluir la conexión a la base de datos
                $servername = "localhost"; 
                $username = "root"; 
                $password = "";
                $dbname = "reto2"; 

                $conn = new mysqli($servername, $username, $password, $dbname);

                // Verificar conexión
                if ($conn->connect_error) {
                    die("Error de conexión: " . $conn->connect_error);
                }

                // Verificar si el formulario fue enviado
                if ($_SERVER["REQUEST_METHOD"] == "POST") {
                    // Capturar los valores enviados del formulario de vuelo
                    
                    $viaje_ID = $conn->real_escape_string($_POST["viaje_ID"]);
                    $Nombre_Evento = $conn->real_escape_string($_POST["Nombre_Evento"]);
                    $nombre_hotel = $conn->real_escape_string($_POST["nombre_hotel"]);
                    $ciudad = $conn->real_escape_string($_POST["ciudad"]);  
                    $precio = $conn->real_escape_string($_POST["precio"]);
                    $fecha_entrada = $conn->real_escape_string($_POST["fecha_entrada"]);
                    $fecha_salida = $conn->real_escape_string($_POST["fecha_salida"]);
                    $tipo_habitacion = $conn->real_escape_string($_POST["tipo_habitacion"]);

                        $sql = "INSERT INTO Alojamientos (ViajeID, NombreEvento, NombreHotel, Ciudad, TipoHabitacion, FechaEntrada, FechaSalida, Precio)
                                VALUES ('$viaje_ID', '$Nombre_Evento', '$nombre_hotel', '$ciudad', '$tipo_habitacion', '$fecha_entrada', '$fecha_salida', '$precio')";
                
                        if ($conn->query($sql) === TRUE) {
                            echo "<script>alert('Viaje registrado correctamente'); window.location.href='form_planificacion.php';</script>";
                        } else {
                            echo "Error: " . $conn->error;
                        }
                    }
                
                $conn->close();
                ?>