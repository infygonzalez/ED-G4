<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="form_planificacion.css">
    <title>Registros de Servicio</title>
    <style>
        .oculto { display: none; }
    </style>
</head>
<body>
    <header>
        <img class="cabecera" src="Imgs/cabecera.jpg" alt="Fondo del encabezado">
        <div class="titulo">Erreka-Mari Viajes</div>
    </header>
    <div class="CerrarSesion"> 
        <a href="Cerrar_sesion.php" class="cta">
            <svg width="10px" height="10px" viewBox="0 0 13 10">
                <path d="M12,5 L2,5"></path>
                <polyline points="5 1 1 5 5 9"></polyline>
            </svg>
            <span>Cerrar Sesión</span>
        </a><br>
    </div>
    <div class="subtitulo">
        <h2>Bienvenido a Registros de Servicio</h2>
    </div>
    <div class="container">
        <h2>Seleccionar viaje</h2>
            <?php
                // Conexión a la base de datos
                error_reporting(E_ALL);
                ini_set('display_errors', 1);
                
                $servername = "localhost";
                $username = "root";
                $password = "";
                $dbname = "reto2";

                $conn = new mysqli($servername, $username, $password, $dbname);
                
                if ($conn->connect_error) {
                    die("Conexión fallida: " . $conn->connect_error);
                }
                
                // Consultar la tabla de aerolinea
                $sql = "SELECT ViajeID FROM Viajes ORDER BY ViajeID ASC";
                $result = $conn->query($sql);

                if ($result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {
                        // Mostrar las aerolineas en el select
                    }
                } else {
                    echo '<option value="">No se encontraron Viajes</option>';
                }

                $conn->close();
            ?>
        </select>
        
        <label id="primera-pregunta">¿Qué servicio deseas registrar?</label>
        <div class="radio-group">
            <input type="radio" name="servicio" value="vuelo" onclick="mostrarFormulario('vuelo')">
            <label><b>Vuelo</b></label>
            <input type="radio" name="servicio" value="alojamiento" onclick="mostrarFormulario('alojamiento')">
            <label><b>Alojamiento</b></label>
            <input type="radio" name="servicio" value="otros" onclick="mostrarFormulario('otros')">
            <label><b>Otros</b></label>
        </div>

        <!-- Formulario VUELO -->
        <form id="form-vuelo" class="oculto" method="POST" action="procesar_formulario_vuelo.php">
            <p><b>Vuelo</b></p>
            <hr>
                <label>¿Qué tipo de vuelo quieres?</label>
                <div class="radio-group">
                    <input type="radio" name="tipo_vuelo" value="ida" onclick="mostrarFormularioVuelta('ida')">
                    <label><b>Ida</b></label>
                    <input type="radio" name="tipo_vuelo" value="ida-vuelta" onclick="mostrarFormularioVuelta('ida-vuelta')">
                    <label><b>Ida / Vuelta</b></label>
                </div>
                <label>Seleccionar Viaje</label>
                <select name="ViajeID_vuelo" id="ViajeID_vuelo">
            <option>-Seleccionar-</option>
            <?php
                // Conexión a la base de datos
                error_reporting(E_ALL);
                ini_set('display_errors', 1);
                
                $servername = "localhost";
                $username = "root";
                $password = "";
                $dbname = "reto2";

                $conn = new mysqli($servername, $username, $password, $dbname);
                
                if ($conn->connect_error) {
                    die("Conexión fallida: " . $conn->connect_error);
                }
                
                // Consultar la tabla de aerolinea
                $sql = "SELECT ViajeID FROM Viajes ORDER BY ViajeID ASC";
                $result = $conn->query($sql);

                if ($result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {
                        // Mostrar las aerolineas en el select
                        echo '<option value="' . $row['ViajeID'] . '">' . $row['ViajeID'] . '</option>';
                    }
                } else {
                    echo '<option value="">No se encontraron Viajes</option>';
                }

                $conn->close();
            ?>
        </select>
                <label>Nombre evento</label>
                <input type="text" id="nombre_evento" name="nombre_evento">
                <label>Aeropuerto de origen</label>
                <select id="Aero_origen" name="Aero_origen">
                    <option>-Seleccionar-</option>
                    <?php
                // Conexión a la base de datos
                error_reporting(E_ALL);
                ini_set('display_errors', 1);
                
                $servername = "localhost";
                $username = "root";
                $password = "";
                $dbname = "reto2";

                $conn = new mysqli($servername, $username, $password, $dbname);
                
                if ($conn->connect_error) {
                    die("Conexión fallida: " . $conn->connect_error);
                }
                
                // Consultar la tabla de aerolinea
                $sql = "SELECT CodigoIATA, NombreAeropuerto FROM Aeropuerto ORDER BY NombreAeropuerto ASC";
                $result = $conn->query($sql);

                if ($result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {
                        // Mostrar las aerolineas en el select
                        echo '<option value="' . $row['CodigoIATA'] . '">' . $row['NombreAeropuerto'] . '</option>';
                    }
                } else {
                    echo '<option value="">No se encontraron Aerolineas</option>';
                }

                $conn->close();
            ?>
                </select>
            <label>Aeropuerto de destino</label>
            <select id="Aero_destino" name="Aero_destino">
                <option>-Seleccionar-</option>
                <?php
                // Conexión a la base de datos
                error_reporting(E_ALL);
                ini_set('display_errors', 1);
                
                $servername = "localhost";
                $username = "root";
                $password = "";
                $dbname = "reto2";

                $conn = new mysqli($servername, $username, $password, $dbname);
                
                if ($conn->connect_error) {
                    die("Conexión fallida: " . $conn->connect_error);
                }
                
                // Consultar la tabla de aerolinea
                $sql = "SELECT CodigoIATA, NombreAeropuerto FROM Aeropuerto ORDER BY NombreAeropuerto ASC";
                $result = $conn->query($sql);

                if ($result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {
                        // Mostrar las aerolineas en el select
                        echo '<option value="' . $row['CodigoIATA'] . '">' . $row['NombreAeropuerto'] . '</option>';
                    }
                } else {
                    echo '<option value="">No se encontraron Aerolineas</option>';
                }

                $conn->close();
            ?>
            </select>
            
            <label>Código de vuelo</label>
            <input type="text" id="codigo_vuelo" name="codigo_vuelo">
            <label>Aerolínea</label>
            <select name="codigo_aerolinea" id="codigo_aerolinea">
                <option>-Seleccionar-</option>
                <?php
                // Conexión a la base de datos
                error_reporting(E_ALL);
                ini_set('display_errors', 1);
                
                $servername = "localhost";
                $username = "root";
                $password = "";
                $dbname = "reto2";

                $conn = new mysqli($servername, $username, $password, $dbname);
                
                if ($conn->connect_error) {
                    die("Conexión fallida: " . $conn->connect_error);
                }
                
                // Consultar la tabla de aerolinea
                $sql = "SELECT CodigoAerolinea, NombreAerolinea FROM Aerolinea ORDER BY NombreAerolinea ASC";
                $result = $conn->query($sql);

                if ($result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {
                        // Mostrar las aerolineas en el select
                        echo '<option value="' . $row['CodigoAerolinea'] . '">' . $row['NombreAerolinea'] . '</option>';
                    }
                } else {
                    echo '<option value="">No se encontraron Aerolineas</option>';
                }

                $conn->close();
            ?>
            </select>
            <label>Precio (€)</label>
            <input type="number" name="precio_vuelos" id="precio_vuelos">
            <label>Fecha de salida</label>
            <input type="date" name="fecha_salida" id="fecha_salida">
            <label>Hora de salida</label>
            <input type="time" name="hora_salida" id="hora_salida">
            <label>Duracion</label>
            <input type="time" name="duracion" id="duracion">
            <div id="form-ida-vuelta" class="oculto">
                <p><b>Vuelo (vuelta)</b></p>
                <hr>
                <label>Fecha de vuelta</label>
                <input type="date" name="fecha_vuelta" id="fecha_vuelta">
                <label>Hora de vuelta</label>
                <input type="time" name="hora_vuelta" id="hora_vuelta">
                <label>Duración del vuelo de vuelta</label>
                <input type="time" name="duracion_vuelta" id="duracion_vuelta">
                <label>Código del vuelo de vuelta</label>
                <input type="text" name="codigo_vuelta" id="codigo_vuelta">
                <label>Aerolínea de vuelta</label>
                <select name="aerolinea_vuelta" id="aerolinea_vuelta">
                    <option>-Seleccionar-</option>
                    <?php
                // Conexión a la base de datos
                error_reporting(E_ALL);
                ini_set('display_errors', 1);
                
                $servername = "localhost";
                $username = "root";
                $password = "";
                $dbname = "reto2";

                $conn = new mysqli($servername, $username, $password, $dbname);
                
                if ($conn->connect_error) {
                    die("Conexión fallida: " . $conn->connect_error);
                }
                
                // Consultar la tabla de aerolinea
                $sql = "SELECT CodigoAerolinea, NombreAerolinea FROM Aerolinea ORDER BY NombreAerolinea ASC";
                $result = $conn->query($sql);

                if ($result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {
                        // Mostrar las aerolineas en el select
                        echo '<option value="' . $row['CodigoAerolinea'] . '">' . $row['NombreAerolinea'] . '</option>';
                    }
                } else {
                    echo '<option value="">No se encontraron Aerolineas</option>';
                }

                $conn->close();
            ?>
                </select>
                <label>Aeropuerto origen vuelta</label>
                <select name="aeropuerto_origen_vuelta" id="aeropuerto_origen_vuelta">
                    <option>-Seleccionar-</option>
                <?php
                // Conexión a la base de datos
                error_reporting(E_ALL);
                ini_set('display_errors', 1);
                
                $servername = "localhost";
                $username = "root";
                $password = "";
                $dbname = "reto2";

                $conn = new mysqli($servername, $username, $password, $dbname);
                
                if ($conn->connect_error) {
                    die("Conexión fallida: " . $conn->connect_error);
                }
                
                // Consultar la tabla de aerolinea
                $sql = "SELECT CodigoIATA, NombreAeropuerto FROM Aeropuerto ORDER BY NombreAeropuerto ASC";
                $result = $conn->query($sql);

                if ($result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {
                        // Mostrar las aerolineas en el select
                        echo '<option value="' . $row['CodigoIATA'] . '">' . $row['NombreAeropuerto'] . '</option>';
                    }
                } else {
                    echo '<option value="">No se encontraron Aerolineas</option>';
                }

                $conn->close();
            ?>
                </select>
                <label>Aeropuerto destino vuelta</label>
                <select name="aeropuerto_destino_vuelta" id="aeropuerto_destino_vuelta">
                    <option>-Seleccionar-</option>
                <?php
                // Conexión a la base de datos
                error_reporting(E_ALL);
                ini_set('display_errors', 1);
                
                $servername = "localhost";
                $username = "root";
                $password = "";
                $dbname = "reto2";

                $conn = new mysqli($servername, $username, $password, $dbname);
                
                if ($conn->connect_error) {
                    die("Conexión fallida: " . $conn->connect_error);
                }
                
                // Consultar la tabla de aerolinea
                $sql = "SELECT CodigoIATA, NombreAeropuerto FROM Aeropuerto ORDER BY NombreAeropuerto ASC";
                $result = $conn->query($sql);

                if ($result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {
                        // Mostrar las aerolineas en el select
                        echo '<option value="' . $row['CodigoIATA'] . '">' . $row['NombreAeropuerto'] . '</option>';
                    }
                } else {
                    echo '<option value="">No se encontraron Aerolineas</option>';
                }

                $conn->close();
            ?>
                </select>
            </div>
            <button type="submit"><b>GUARDAR SERVICIO</b></button>
        </form>

        <!-- Formulario ALOJAMIENTO -->
        <form id="form-alojamiento" class="oculto" method="POST" action="procesar_formulario_alojamiento.php">
            <p><b>Alojamiento</b></p>
            <hr>
            <label>Seleccionar Viaje</label>
        <select name="viaje_ID" id="viaje_ID">
            <option>-Seleccionar-</option>
            <?php
                // Conexión a la base de datos
                error_reporting(E_ALL);
                ini_set('display_errors', 1);
                
                $servername = "localhost";
                $username = "root";
                $password = "";
                $dbname = "reto2";

                $conn = new mysqli($servername, $username, $password, $dbname);
                
                if ($conn->connect_error) {
                    die("Conexión fallida: " . $conn->connect_error);
                }
                
                // Consultar la tabla de aerolinea
                $sql = "SELECT ViajeID FROM Viajes ORDER BY ViajeID ASC";
                $result = $conn->query($sql);

                if ($result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {
                        // Mostrar las aerolineas en el select
                        echo '<option value="' . $row['ViajeID'] . '">' . $row['ViajeID'] . '</option>';
                    }
                } else {
                    echo '<option value="">No se encontraron Viajes</option>';
                }

                $conn->close();
            ?>
        </select>
            <label>Nombre Evento</label>
            <input type="text" name="Nombre_Evento" id="Nombre_Evento">
            <label>Nombre del hotel</label>
            <input type="text" name="nombre_hotel" id="nombre_hotel">
            <label>Ciudad</label>
            <input type="text" name="ciudad" id="ciudad">
            <label>Precio (€)</label>
            <input type="number" name="precio" id="precio">
            <label>Fecha de entrada</label>
            <input type="date" name="fecha_entrada" id="fecha_entrada">
            <label>Fecha de salida</label>
            <input type="date" name="fecha_salida" id="fecha_salida">
            <label>Tipo de habitación</label>
            <select name="tipo_habitacion" id="tipo_habitacion">
                <option>-Seleccionar-</option>
                <?php
                // Conexión a la base de datos
                error_reporting(E_ALL);
                ini_set('display_errors', 1);
                
                $servername = "localhost";
                $username = "root";
                $password = "";
                $dbname = "reto2";

                $conn = new mysqli($servername, $username, $password, $dbname);
                
                if ($conn->connect_error) {
                    die("Conexión fallida: " . $conn->connect_error);
                }
                
                // Consultar la tabla de Alojamiento
                $sql = "SELECT TipoHabitacion FROM Alojamientos ORDER BY TipoHabitacion ASC";
                $result = $conn->query($sql);

                if ($result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {
                        // Mostrar los tipos de  habitaciones en el select
                        echo '<option value="' . $row['TipoHabitacion'] . '">' . $row['TipoHabitacion'] . '</option>';
                    }
                } else {
                    echo '<option value="">No se encontraron Habitaciones</option>';
                }

                $conn->close();
            ?>
            </select>
            <button type="submit"><b>GUARDAR SERVICIO</b></button>
        </form>
        
        <!-- Formulario OTROS -->
        <form id="form-otros" class="oculto" method="POST" action="procesar_formulario_otros.php">
            <p><b>Otros</b></p>
            <hr>
            <label> Seleccionar Viaje</label>
        <select name="viajeID_otros" id="viajeID_otros">
            <option>-Seleccionar-</option>
            <?php
                // Conexión a la base de datos
                error_reporting(E_ALL);
                ini_set('display_errors', 1);
                
                $servername = "localhost";
                $username = "root";
                $password = "";
                $dbname = "reto2";

                $conn = new mysqli($servername, $username, $password, $dbname);
                
                if ($conn->connect_error) {
                    die("Conexión fallida: " . $conn->connect_error);
                }
                
                // Consultar la tabla de aerolinea
                $sql = "SELECT ViajeID FROM Viajes ORDER BY ViajeID ASC";
                $result = $conn->query($sql);

                if ($result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {
                        // Mostrar las aerolineas en el select
                        echo '<option value="' . $row['ViajeID'] . '">' . $row['ViajeID'] . '</option>';
                    }
                } else {
                    echo '<option value="">No se encontraron Viajes</option>';
                }

                $conn->close();
            ?>
        </select>
            <label>Nombre del servicio</label>
            <input type="text" name="nombre_servicio" id="nombre_servicio">
            <label>Fecha</label>
            <input type="date" name="fecha" id="fecha">
            <label>Descripción</label>
            <textarea  id="descripcion" name="descripcion" placeholder="Añade los servicios excluidos" style="display: block; width: 100%;"></textarea>
            <label>Precio (€)</label>
            <input type="number" name="precio_otros"  id="precio_otros">
            <button type="submit"><b>GUARDAR SERVICIO</b></button>
        </form>

    </div>
    <footer>
        <a href="https://creativecommons.org/"> 
            <img src="Imgs/creative_comons.png" title="Esta página está bajo la licencia de Creative Commons." alt="logo" width="180" class="imagen"> 
        </a>
        <p class="copyright"> &copy; <b>Erreka-Mari Viajes</b></p>
    </footer>
    <script>
        function mostrarFormulario(tipo) {
            // Oculta todos los formularios
            document.getElementById('form-vuelo').classList.add('oculto');
            document.getElementById('form-alojamiento').classList.add('oculto');
            document.getElementById('form-otros').classList.add('oculto');

            // Muestra solo el formulario seleccionado
            document.getElementById('form-' + tipo).classList.remove('oculto');
        }

        function mostrarFormularioVuelta(tipo) {
            let formVuelta = document.getElementById('form-ida-vuelta');
            if (tipo === 'ida-vuelta') {
                formVuelta.classList.remove('oculto');
            } else {
                formVuelta.classList.add('oculto');
            }
        }

        

    
    </script>
</body>
</html>
