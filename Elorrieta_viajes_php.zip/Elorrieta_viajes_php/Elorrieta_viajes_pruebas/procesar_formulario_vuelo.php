<?php
                // Incluir la conexión a la base de datos
                $servername = "localhost"; 
                $username = "root"; 
                $password = "";
                $dbname = "reto2"; 

                $conn = new mysqli($servername, $username, $password, $dbname);

                // Verificar conexión
                if ($conn->connect_error) {
                    die("Error de conexión: " . $conn->connect_error);
                }

                // Verificar si el formulario fue enviado
                if ($_SERVER["REQUEST_METHOD"] == "POST") {
                    // Capturar los valores enviados del formulario de vuelo
                    
                    $ViajeID_vuelo = $conn->real_escape_string($_POST["ViajeID_vuelo"]);
                    $nombre_evento = $conn->real_escape_string($_POST["nombre_evento"]);
                    $Aero_origen = $conn->real_escape_string($_POST["Aero_origen"]);
                    $Aero_destino = $conn->real_escape_string($_POST["Aero_destino"]);
                    $codigo_vuelo = $conn->real_escape_string($_POST["codigo_vuelo"]);
                    $codigo_aerolinea = $conn->real_escape_string($_POST["codigo_aerolinea"]);
                    $precio_vuelos = $conn->real_escape_string($_POST["precio_vuelos"]);
                    $fecha_salida = $conn->real_escape_string($_POST["fecha_salida"]);
                    $hora_salida = $conn->real_escape_string($_POST["hora_salida"]);
                    $duracion = $conn->real_escape_string($_POST["duracion"]);
                    // Si el vuelo es ida y vuelta se capturan los siguientes datos (pueden venir vacíos si no se selecciona ida-vuelta)
                    $fecha_vuelta = $conn->real_escape_string($_POST["fecha_vuelta"]);
                    $hora_vuelta = $conn->real_escape_string($_POST["hora_vuelta"]);
                    $duracion_vuelta = $conn->real_escape_string($_POST["duracion_vuelta"]);
                    $aerolinea_vuelta = $conn->real_escape_string($_POST["aerolinea_vuelta"]);
                    $aeropuerto_origen_vuelta = $conn->real_escape_string($_POST["aeropuerto_origen_vuelta"]);
                    $aeropuerto_destino_vuelta = $conn->real_escape_string($_POST["aeropuerto_destino_vuelta"]);
                    
                    // Insertar los datos en la base de datos
                    $sql = "INSERT INTO Vuelos (ViajeID, NombreEvento, AeropuertoOrigen, AeropuertoDestino, CodigoVuelo, CodigoAerolinea, FechaSalida, HoraSalida, Duracion, FechaRegreso, HoraRegreso, DuracionRegreso, PrecioTotal, AeropuertoOrigenVuelta, AeropuertoDestinoVuelta)
                    VALUES ('$ViajeID_vuelo', '$nombre_evento', '$Aero_origen', '$Aero_destino', '$codigo_vuelo', '$codigo_aerolinea', '$fecha_salida', '$hora_salida', '$duracion', '$fecha_vuelta', '$hora_vuelta', '$duracion_vuelta', '$precio_vuelos', '$aeropuerto_origen_vuelta', '$aeropuerto_destino_vuelta')";

                    if ($conn->query($sql) === TRUE) {
                        echo "Viaje registrado correctamente.";
                    } else {
                        echo "Error al registrar el viaje: " . $conn->error;
                    }

                    // Cerrar conexión
                    $conn->close();
                }
            ?>