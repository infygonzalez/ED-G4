
        

function validateForm() {
            const username = document.getElementById('username').value;
            const password = document.getElementById('password').value;
            const errorMessage = document.getElementById('error-message');

            if (username === '' || password === '') {
                document.getElementById('errorMessage').style.display = 'block';
            } else {
                errorMessage.style.display = 'none';
                alert('¡Inicio de sesión exitoso!'); // Aquí puedes añadir lógica para manejar el inicio de sesión.
            }
        }